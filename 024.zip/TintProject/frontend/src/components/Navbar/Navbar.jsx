import React, { useState } from "react";
import { CiSearch } from "react-icons/ci";
import { FaTrophy } from "react-icons/fa";
import { CiShoppingCart } from "react-icons/ci";
import { NavbarDetails } from "../../data/data";
import { MdMenu } from "react-icons/md";

const Navbar = () => {
  const[open, setOpen] = useState(false)
  return (
    <nav className="bg-gray-100 rounded-lg ">
      <div className="container flex items-center justify-between py-3">
        
          <div className="text-2xl uppercase flex items-center font-bold gap-2">
            
              <img src="https://tint.edu.in/images/tict_logo_new_2019.png" alt="" />
              <p className="text-third text-4xl">TINT</p>
            
          </div>

          <div className="hidden md:flex">
            <ul className="flex gap-6 items-center text-gray-600 text-xl font-semibold"></ul>
           {NavbarDetails.map((item)=>{
            return(
              <li key={item.id}>
                <a href={item.link} className="inline-block py-1 px-3 hover:text-third">{item.title}</a>
              </li>
            )
           })}
          </div>
        

        <div className="flex items-center gap-4 text-2xl">
          <button className="text-2xl hover:bg-main p-2 rounded-full hover:text-white duration-200 font-bold"><CiSearch /></button> 
          <button className="text-2xl hover:bg-main p-2 rounded-full hover:text-white duration-200 font-bold "><CiShoppingCart /></button> 
          <button className="hidden md:block main-btn">Login</button>
        </div>
        <div className="block md:hidden" onClick={()=>{
        setOpen(!open)
      }}>
        <MdMenu className="text-4xl"/>
      </div>
      </div>

      
      
    </nav>
  );
};

export default Navbar;
