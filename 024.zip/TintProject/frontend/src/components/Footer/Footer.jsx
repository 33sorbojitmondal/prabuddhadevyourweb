import { FaFacebook } from "react-icons/fa";
import { CgWebsite, CgYoutube } from "react-icons/cg";
import { FaInstagram } from "react-icons/fa";
import { FaYoutube } from "react-icons/fa";

const Footer = () => {
    return (
      <footer className="bg-gray-800 px-4 md:px-16 lg:px-28 py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h2 className="text-lg font-bold mb-4 text-gray-100">About Us</h2>
            <p className="text-gray-300">
              We are a team dedicated to providing teh best products and services
              to our customers.
            </p>
          </div>
          <div>
            <h2 className="text-lg font-bold mb-4 text-gray-100">Quick Links</h2>
            <ul>
              <li>
                <a href="" className="hover:underline text-gray-300">
                  Home
                </a>
              </li>
  
              <li>
                <a href="" className="hover:underline text-gray-300">
                  Event Details
                </a>
              </li>
  
              <li>
                <a href="" className="hover:underline text-gray-300">
                  Contact
                </a>
              </li>
  
              <li>
                <a href="" className="hover:underline text-gray-300">
                  Register Now
                </a>
              </li>
            </ul>
          </div>
  
          <div >
            <h2 className="text-lg font-bold mb-4 text-gray-100">Follow Us</h2>
            <ul className="flex space-x-4">
              <li>
              <FaFacebook className="text-blue-500" /> <a  href="https://www.facebook.com/tint.edu.in/" className="hover:underline text-gray-300">
                  Facebook
                </a>
              </li>

              <li>
              <CgWebsite className="text-blue-500" /> <a href="https://tint.edu.in/" className="hover:underline text-gray-300">
                  Website
                </a>
              </li>
  
              <li>
              <FaInstagram className="text-blue-500" /> <a href="https://www.instagram.com/technointernationalnewtown/" className="hover:underline text-gray-300">
                  Instagram
                </a>
              </li>

              <li>
              <CgYoutube className="text-blue-500" /> <a href="https://youtu.be/YM7oXXURwA0?si=iu2EQmITWuOpvj6A" className="hover:underline text-gray-300">
                  Youtube
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-600 pt-6 text-gray-300 text-center mt-6">
          <p>@ 2025 Code with Akash. All Rights Reserved</p>
        </div>
      </footer>
    );
  };
  
  export default Footer;