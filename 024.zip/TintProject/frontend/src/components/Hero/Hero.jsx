import React from 'react'

const Hero = () => {
  return (
    <section className='bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] justify-between'>
        <div className='container grid grid-cols-1 md:grid-cols-2 min-h-[660px] relative'>
            <div className='flex flex-col justify-center py-14 md:py-0 font-Playfair '>
                <div className='text-center space-y-6 md:text-left md:justify-center'>
                    <h1 className='text-5xl lg:text-8xl font-playfair font-bold leading-relaxed md:leading-normal '>
                        PRABUDDHA 
                        <br />
                        <span className='mx-6 text-third'>2025</span>
                    </h1>
                    <p className='text-gray-800 xl:max-w-[400px] font-semibold text-3xl'>
                        Step out of your comfort zone and dive into the world of innovation!
                    </p>

                    <div className='flex items-center justify-center lg:justify-left w-[350px] md:w-[700px] drop-shadow-md gap-8'>
                        <button className='main-btn flex items-center '>Participate Now</button>
                        <button className='sec-btn'>See Details</button>
                    </div>
                </div>
                
                
            </div>
            <div className='flex justify-center items-center w-[350px] md:w-[700px] drop-shadow-md'>
                    <img src="https://tint.edu.in/images/tict_logo_new_2019.png" alt="" className='w-72' />

                </div>
        </div>
    </section>
  )
}

export default Hero
