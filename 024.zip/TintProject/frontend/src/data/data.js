export const NavbarDetails = [
  { id: 1, title: "Home", link: "/" },
  {
    id: 2,
    title: "About Us",
    link: "#",
  },
  {
    id: 3,
    title: "Event Details",
    link: "#",
  },
];
