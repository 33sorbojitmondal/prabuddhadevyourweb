/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        main: "#023047",
        second: "#219EBC",
        bg1: "#8ECAE6",
        bg2: "#FFB703",
        third: "#FB8500",
      },
      fontFamily: ["Playfair Display", "serif"],

      container: {
        center: true,
        padding: {
          DEFAULT: "1rem",
          sm: "2rem",
          xl: "5rem",
          lg: "6rem",
          "2xl": "7rem",
        },
      },
    },
  },
  plugins: [],
};
