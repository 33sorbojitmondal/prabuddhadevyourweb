import React from "react";

const AboutUs = () => {
  return (
    <div className="bg-gray-100 min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold text-center text-indigo-600 mb-10">
          About Prabuddha 2025
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="flex justify-center">
            <img
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuoDceuSU8EgZpudQEmaM62Gbb8AhK86WgOg&s"
              alt="Tech Fest"
              className="rounded-lg shadow-lg"
            />
          </div>

          <div>
            <h2 className="text-3xl font-semibold text-indigo-800 mb-4">
              Welcome to Tech Fest 2025!
            </h2>
            <p className="text-gray-700 mb-6">
              Techno International New Town, Kolkata is going to organize
              “Prabuddha”-Tech Fest on February 27 th Feb to 1st Mar, 2025,
              Thursday, Friday and Saturday. We invite your active participation
              in this Tech Fest by exploring emerging technologies and solving
              real-world challenges. It aims to foster learning, networking, and
              collaboration, driving the future of technology forward providing
              a platform for tech enthusiasts. The primary goal of the Tech Fest
              is to encourage innovation, creativity and knowledge-sharing to
              empower future tech leaders and to showcase the advancements in
              AI, cybersecurity and other emerging technologies.
            </p>
            <p className="text-gray-700 mb-6">
              From workshops on cutting-edge technologies to keynote speeches by
              leaders in the tech industry, Prabuddha 2025 offers something for
              everyone. Whether you're a developer, a startup founder, or just
              someone who is passionate about technology, this event is designed
              to inspire and empower.
            </p>
            <p className="text-gray-700">
              Join us for a week of learning, networking, and discovery as we
              explore the latest trends in artificial intelligence, webdev,
              cybersecurity, and more. Be a part of the future of tech!
            </p>
          </div>
        </div>

        <div className="mt-16">
          <h2 className="text-3xl font-semibold text-center text-indigo-800 mb-10">
            Our Core Values
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-2xl font-bold text-indigo-700 mb-4">
                Innovation
              </h3>
              <p className="text-gray-700">
                We believe in pushing the boundaries of technology and fostering
                a culture of innovation.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-2xl font-bold text-indigo-700 mb-4">
                Collaboration
              </h3>
              <p className="text-gray-700">
                We encourage collaboration between individuals and organizations
                to create solutions that benefit society.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-2xl font-bold text-indigo-700 mb-4">
                Education
              </h3>
              <p className="text-gray-700">
                Continuous learning is at the core of everything we do, with
                workshops and seminars designed to inspire.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;
