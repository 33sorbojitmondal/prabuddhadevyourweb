import React from "react";

const EventDetails = () => {
  const events = [
    {
      id: 1,
      title: "AI & Machine Learning Workshop",
      description:
        "Explore the future of AI and Machine Learning in this hands-on workshop. Learn the basics of ML models, algorithms, and more.",
      date: "March 15, 2025",
      elegibility: "all",
      time: "10:00 AM - 4:00 PM",
      prize: "exciting prizes",
    },
    {
      id: 2,
      title: "Dev you web",
      description:
        "Dive into the world of Web3 and understand how Blockchain technology is shaping the decentralized web.",
      date: "March 16, 2025",
      elegibility: "all",
      time: "11:00 AM - 3:00 PM",
      prize: "exciting prizes",
    },
    {
      id: 3,
      title: "Ai Bootcamp",
      description:
        "Get insights into the latest trends in cybersecurity and hands-on experience with ethical hacking.",
      date: "March 17, 2025",
      elegibility: "all",
      time: "12:00 PM - 5:00 PM",
      prize: "exciting prizes",
    },
  ];

  return (
    <div className="bg-gray-100 min-h-screen p-6">
      <h1 className="text-4xl font-bold text-center text-indigo-600 mb-10">
        Tech Fest 2025 - Event Details
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {events.map((event) => (
          <div key={event.id} className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-semibold mb-2 text-indigo-800">
              {event.title}
            </h2>
            <p className="text-gray-700 mb-4">{event.description}</p>
            <div className="text-gray-600 mb-2">
              <strong>Date:</strong> {event.date}
            </div>
            <div className="text-gray-600 mb-2">
              <strong>Time:</strong> {event.time}
            </div>
            <div className="text-gray-600">
              <strong>Prizes:</strong> {event.prize}
            </div>
            <div className="text-gray-600">
              <strong>elegibility:</strong> {event.elegibility}
            </div>
            
            <button className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 transition duration-300">
              Register Now
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EventDetails;