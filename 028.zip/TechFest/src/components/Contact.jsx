import React, { useState } from "react";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    console.log(formData);
    setSubmitted(true);
  };

  return (
    <div className="bg-gray-100 min-h-screen p-6">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-lg">
        <h1 className="text-3xl font-bold text-center text-indigo-600 mb-8">
          Contact Us
        </h1>
        {submitted ? (
          <div className="text-center">
            <h2 className="text-2xl font-bold text-green-500 mb-4">
              Message Sent!
            </h2>
            <p>Thank you for reaching out. We will get back to you soon.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label
                htmlFor="name"
                className="block text-gray-700 text-sm font-bold mb-2"
              >
                Name:
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring focus:border-indigo-300"
                required
              />
            </div>

            <div className="mb-6">
              <label
                htmlFor="email"
                className="block text-gray-700 text-sm font-bold mb-2"
              >
                Email:
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring focus:border-indigo-300"
                required
              />
            </div>

            <div className="mb-6">
              <label
                htmlFor="message"
                className="block text-gray-700 text-sm font-bold mb-2"
              >
                Message:
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring focus:border-indigo-300"
                rows="6"
                required
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition duration-300"
            >
              Send Message
            </button>
          </form>
        )}
      </div>


      <div className="mt-16">
        <h2 className="text-3xl font-semibold text-center text-indigo-800 mb-8">
          Get in Touch
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <h3 className="text-2xl font-bold text-indigo-700 mb-4">Email</h3>
            <p className="text-gray-700">tint</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <h3 className="text-2xl font-bold text-indigo-700 mb-4">Phone</h3>
            <p className="text-gray-700">000000000</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <h3 className="text-2xl font-bold text-indigo-700 mb-4">Address</h3>
            <p className="text-gray-700">
              Newtown
            </p>
          </div>
        </div>
      </div>
      <div>
      <h2 className="text-3xl font-semibold text-center text-indigo-800 mb-8">
          FAQ
        </h2>
        <p>
        1.Register within the deadline using the provided link.
2. All undergraduate students are eligible to participate in different competition.
3. No participants are allowed to take part in two parallel competitions.
4. Keep a copy of your registration confirmation and ID card in time of physical verification on the day of events.
5. Carry a laptop, charger, USB drives, and necessary equipment.
6. Arrive at the venue on time and follow the schedule.
7.Follow ethical practices—no plagiarism or rule violations.
8.Cooperate with event coordinators and adhere to instructions.
9.Maintain professional behaviour with judges, organizers, and other participants.
10.Stick to the given time limits for the events.
11. Follow all safety protocols, especially in hardware-related events.
12.Respect the venue rules and avoid damaging property.
13. Avoid disruptive behaviour or misconduct during the fest.
14.provide us the mandatory feedback to improve future tech fests.
15.Registration fee for each event is INR 100 (except creative canvas and science day celebration).
        </p>
      </div>
    </div>
  );
};

export default Contact;