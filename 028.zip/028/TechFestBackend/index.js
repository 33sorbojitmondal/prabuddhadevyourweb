const express = require('express')
const { connectDb } = require("./config/database");
const userRouter = require("./routes/user.Routes");
const app = express();
connectDb();

app.use(express.json());


app.use("/api/v1/user", userRouter);
app.get('/', function (req, res) {
    res.send('Hello World')
  })
app.get 
  app.listen(3000)