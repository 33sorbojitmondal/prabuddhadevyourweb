const mongoose = require('mongoose');

exports.connectDb = async () => {
  try {
    await mongoose.connect("mongodb+srv://k92531707:q9ncob91CgrDc8Zz@cluster0.3t3ny.mongodb.net/");
    console.log("MongoDB connection Established...");
  } catch (error) {
    console.error(error.message);
  }
}