import React, { useState } from "react";

const Registration = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    college: "",
    year: "",
    event: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    console.log(formData);
    setSubmitted(true);
  };

  return (
    <div className="bg-gray-100 min-h-screen p-6">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow-lg">
        <h1 className="text-3xl font-bold text-center text-indigo-600 mb-8">
          Register for Tech Fest 2025
        </h1>
        {submitted ? (
          <div className="text-center">
            <h2 className="text-2xl font-bold text-green-500 mb-4">
              Registration Successful!
            </h2>
            <p>Thank you for registering for Tech Fest 2025. We will contact you soon.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label
                htmlFor="name"
                className="block text-gray-700 text-sm font-bold mb-2"
              >
                Name:
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring focus:border-indigo-300"
                required
              />
            </div>

            <div className="mb-6">
              <label
                htmlFor="email"
                className="block text-gray-700 text-sm font-bold mb-2"
              >
                Email:
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring focus:border-indigo-300"
                required
              />
            </div>

            <div className="mb-6">
              <label
                htmlFor="phone"
                className="block text-gray-700 text-sm font-bold mb-2"
              >
                Phone:
              </label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring focus:border-indigo-300"
                required
              />
            </div>

            <div className="mb-6">
              <label
                htmlFor="collegeName"
                className="block text-gray-700 text-sm font-bold mb-2"
              >
                College Name:
              </label>
              <input
                type="college"
                id="college"
                name="college"
                value={formData.college}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring focus:border-indigo-300"
                required
              />
            </div>

            <div className="mb-6">
              <label
                htmlFor="year"
                className="block text-gray-700 text-sm font-bold mb-2"
              >
                Year of Study:
              </label>
              <input
                type="year"
                id="year"
                name="year"
                value={formData.year}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring focus:border-indigo-300"
                required
              />
            </div>

            <div className="mb-6">
              <label
                htmlFor="event"
                className="block text-gray-700 text-sm font-bold mb-2"
              >
                Select Event:
              </label>
              <select
                id="event"
                name="event"
                value={formData.event}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg shadow-sm focus:outline-none focus:ring focus:border-indigo-300"
                required
              >
                <option value="">-- Please select an event --</option>
                <option value="AI & ML Workshop">AI & ML Workshop</option>
                <option value="Blockchain in Web3">Blockchain in Web3</option>
                <option value="Cybersecurity Bootcamp">
                  Cybersecurity Bootcamp
                </option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition duration-300"
            >
              Register Now
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default Registration;