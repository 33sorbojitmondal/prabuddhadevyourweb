import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";

const Home = () => {
  const navigate = useNavigate();
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const eventDate = new Date("2025-07-15T00:00:00").getTime();

    const countdown = setInterval(() => {
      const now = new Date().getTime();
      const timeRemaining = eventDate - now;

      if (timeRemaining < 0) {
        clearInterval(countdown);
        return;
      }

      const days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
      const hours = Math.floor(
        (timeRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
      );
      const minutes = Math.floor(
        (timeRemaining % (1000 * 60 * 60)) / (1000 * 60)
      );
      const seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    }, 1000);

    return () => clearInterval(countdown);
  }, []);

  return (
    <>
      <Navbar />
      <div className="bg-gray-100 min-h-screen p-6">
        <div className="max-w-5xl mx-auto text-center py-20">
          <h1 className="text-5xl font-bold text-indigo-600 mb-4">
            Welcome to Prabuddha
          </h1>
          <p className="text-xl text-gray-700 mb-8">COMPETE CREATE CONQUER</p>
          <p className="text-xl text-gray-700 mb-8">
            Techno International New Town, Kolkata is going to organize
            “Prabuddha”-Tech Fest on February 27 th Feb to 1st Mar, 2025,
            Thursday, Friday and Saturday. We invite your active participation
            in this Tech Fest by exploring emerging technologies and solving
            real-world challenges.
          </p>
          <div className="bg-white p-8 rounded-lg shadow-lg inline-block">
            <h2 className="text-3xl font-bold text-indigo-600 mb-6">
              Event Countdown
            </h2>
            <div className="flex justify-center space-x-8">
              <div className="text-center">
                <p className="text-4xl font-semibold text-indigo-700">
                  {timeLeft.days}
                </p>
                <p className="text-sm text-gray-600">Days</p>
              </div>
              <div className="text-center">
                <p className="text-4xl font-semibold text-indigo-700">
                  {timeLeft.hours}
                </p>
                <p className="text-sm text-gray-600">Hours</p>
              </div>
              <div className="text-center">
                <p className="text-4xl font-semibold text-indigo-700">
                  {timeLeft.minutes}
                </p>
                <p className="text-sm text-gray-600">Minutes</p>
              </div>
              <div className="text-center">
                <p className="text-4xl font-semibold text-indigo-700">
                  {timeLeft.seconds}
                </p>
                <p className="text-sm text-gray-600">Seconds</p>
              </div>
            </div>
          </div>

          <div className="mt-12">
            <a
              href="/Registration"
              className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-indigo-700 transition duration-300"
            >
              Register Now
            </a>
            <a
              href="/event"
              className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-indigo-700 transition duration-300"
            >
              View Events
            </a>
            <a
              href="/contact"
              className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-indigo-700 transition duration-300"
            >
              Contact Us
            </a>
          </div>
        </div>
        <Footer />
      </div>
    </>
  );
};

export default Home;
