import { useState } from 'react'

import { Routes, Route } from 'react-router-dom';
import About from './components/Aboutus';
import Home from './components/Home';
import Registration from './components/Registration';
import './App.css'
import Contact from './components/Contact';
import EventDetails from './components/Event';

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="registration" element={<Registration />} />
        <Route path="contact" element={<Contact />} />
        <Route path="event" element={<EventDetails />} />
      </Routes>
    </div>
  )
}

export default App
