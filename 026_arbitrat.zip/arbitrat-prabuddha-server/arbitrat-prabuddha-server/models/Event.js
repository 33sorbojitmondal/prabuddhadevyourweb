const mongoose = require("mongoose");


const eventSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    category: {
        type: String,
        enum: ["AI", "WebDev", "Coding", "Robotics"],
        required: true,
    },
    description: String,
    rules: 
        {
            type: String,
        }
    ,
    banner: String,
    eventDate: {
      type: Date,
    },
    eventTime: {
        type: Date,
    },
    prize:String,
    venue: String,
  },
  {
    timestamps: true,
  }
);

// eventSchema.pre(/^find/, function (next) {
//   // Only populate necessary fields
//   this.populate({
//     path: "organizerId",
//     select: "name email",
//   });
//   next();
// });



eventSchema.index(
  { name: "text" },
  {
    weights: {
      name: 10,
    },
    name: "EventTextIndex",
  }
);



const Event = mongoose.model("Event", eventSchema);

// Create indexes
Event.createIndexes().catch(console.error);

module.exports = Event;