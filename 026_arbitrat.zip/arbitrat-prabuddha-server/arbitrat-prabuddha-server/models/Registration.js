const mongoose = require("mongoose");

const registrationSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        reference: "User"
    },
    eventId:{
        type: mongoose.Schema.Types.ObjectId,
        reference: "Event"
    },
},
{
    timestamps: true,
  }
)