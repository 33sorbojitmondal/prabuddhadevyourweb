const express = require("express");
const router = express.Router();

const registrationController = require("../controllers/registrationController");

//const auth = require("../middleware/auth");




// Public routes
router.get("/",  registrationController.getAllRegistrations);
router.get("/:id", registrationController.getRegistration);
router.post("/", registrationController.createRegistration);

// Protected routes
//router.use(auth);



router.patch("/:id", registrationController.updateRegistration);
router.delete("/:id", registrationController.deleteRegistration);




module.exports = router;