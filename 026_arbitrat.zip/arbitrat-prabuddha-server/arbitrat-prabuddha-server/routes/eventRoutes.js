const express = require("express");
const router = express.Router();

const eventController = require("../controllers/eventController");

//const auth = require("../middleware/auth");




// Public routes
router.get("/",  eventController.getAllEvents);
router.get("/:id", eventController.getEvent);

// Mount participant routes for each event
//router.use("/:eventId/register", participantRoutes);
//router.use("/:eventId/participants", participantRoutes);



// Protected routes
//router.use(auth);


router.post("/", eventController.createEvent);
router.patch("/:id", eventController.updateEvent);
router.delete("/:id", eventController.deleteEvent);



// router.get(
//   "/:eventId/participation",
//   auth,
//   eventController.getEventParticipation
// );


module.exports = router;