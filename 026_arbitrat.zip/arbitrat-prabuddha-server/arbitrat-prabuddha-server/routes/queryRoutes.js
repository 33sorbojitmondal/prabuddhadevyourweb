const express = require("express");
const router = express.Router();

const queryController = require("../controllers/queryController");

//const auth = require("../middleware/auth");




// Public routes
router.get("/",  queryController.getAllQuerys);
router.get("/:id", queryController.getQuery);
router.post("/", queryController.createQuery);

// Protected routes
//router.use(auth);



router.patch("/:id", queryController.updateQuery);
router.delete("/:id", queryController.deleteQuery);




module.exports = router;