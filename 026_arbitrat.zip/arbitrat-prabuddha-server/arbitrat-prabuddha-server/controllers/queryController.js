// controllers/QueryController.js
const Query = require('../models/Query');
const factory = require('../utils/handlerFactory');

exports.getAllQuerys = factory.getAll(Query);
exports.createQuery = factory.createOne(Query);
exports.updateQuery = factory.updateOne(Query);
exports.getQuery = factory.getOne(Query);
exports.deleteQuery = factory.deleteOne(Query);