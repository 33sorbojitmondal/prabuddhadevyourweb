// controllers/EventController.js
const Event = require('../models/Event');
const factory = require('../utils/handlerFactory');

exports.getAllEvents = factory.getAll(Event);
exports.createEvent = factory.createOne(Event);
exports.updateEvent = factory.updateOne(Event);
exports.getEvent = factory.getOne(Event);
exports.deleteEvent = factory.deleteOne(Event);