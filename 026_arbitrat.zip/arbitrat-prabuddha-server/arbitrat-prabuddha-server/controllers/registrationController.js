// controllers/RegistrationController.js
const Registration = require('../models/Registration');
const factory = require('../utils/handlerFactory');

exports.getAllRegistrations = factory.getAll(Registration);
exports.createRegistration = factory.createOne(Registration);
exports.updateRegistration = factory.updateOne(Registration);
exports.getRegistration = factory.getOne(Registration);
exports.deleteRegistration = factory.deleteOne(Registration);