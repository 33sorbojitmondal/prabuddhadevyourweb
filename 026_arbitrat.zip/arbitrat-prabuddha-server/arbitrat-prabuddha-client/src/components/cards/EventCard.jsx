export default function EventCard({event}) {
    return (
        <div className="shadow-md border border-gray-200 w-full p-4 rounded-lg flex flex-col items-start justify-between">
            <h2 className="text-xl font-semibold">
                {event.name}
            </h2>
            <p>{event.category}</p>
            <p>{event.prize}</p>
            <p>{event.venue}</p>
        </div>
    )
}