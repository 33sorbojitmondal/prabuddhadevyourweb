import { useState } from 'react'

export default function FaqAccordion({ faq }) {

    const [open, setOpen] = useState(false)

    const toggleOpen = () => {
        setOpen(prev => !prev)
    }

    return (
        <div
            className="flex flex-col max-w-2xl shadow-md"
        >
            <div className='flex justify-between items-center p-4 hover:cursor-pointer rounded-lg' 
            onClick={() => toggleOpen()}> 
                <p className='text-lg'>{faq.question}</p>
                <div className="w-10 h-10 flex justify-center items-center">
                    {
                        open ? <UpArrowIcon/> : <DownArrowIcon/>
                    }
                </div>
            </div>
            {
                open && (
                    <div className='p-4 text-left text-black'>
                        {faq.answer}
                    </div>
                )
            }
        </div>
    )
}

const DownArrowIcon = () => {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style={{fill: "rgba(10, 22, 63, 1)"}}><path d="M16.939 7.939 12 12.879l-4.939-4.94-2.122 2.122L12 17.121l7.061-7.06z"></path></svg>
    )
}

const UpArrowIcon = () => {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style={{fill: "rgba(10, 22, 63, 1)"}}><path d="m6.293 13.293 1.414 1.414L12 10.414l4.293 4.293 1.414-1.414L12 7.586z"></path></svg>
    )
}