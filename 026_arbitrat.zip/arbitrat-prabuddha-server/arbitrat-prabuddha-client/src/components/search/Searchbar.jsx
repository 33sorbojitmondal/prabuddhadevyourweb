import { useState } from "react"

export default function Searchbar({ handleSubmit }) {

    const [text, setText] = useState('')

    return  (
        <form 
            className="relative w-full max-w-2xl flex"
        >
            <input
            name="q"
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={"Search any event here.."}
            className="w-full px-6 py-4 border border-gray-800 rounded-l-lg text-gray-800 text-lg focus:outline-none"
            />
            <button
            onClick={(e) => {
                e.preventDefault()
                console.log(text)
                handleSubmit(text)
            }}
            title="search"
            className="bg-gray-800 text-white border border-gray-800 px-8 py-4 rounded-r-lg hover:bg-gray-900 transition flex items-center justify-center"
            >
            <SearchIcon/>
            </button>
        </form>
    )
}

const SearchIcon = () => {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style={{ fill: "white"}}><path d="M10 18a7.952 7.952 0 0 0 4.897-1.688l4.396 4.396 1.414-1.414-4.396-4.396A7.952 7.952 0 0 0 18 10c0-4.411-3.589-8-8-8s-8 3.589-8 8 3.589 8 8 8zm0-14c3.309 0 6 2.691 6 6s-2.691 6-6 6-6-2.691-6-6 2.691-6 6-6z"></path></svg> 
    )
}