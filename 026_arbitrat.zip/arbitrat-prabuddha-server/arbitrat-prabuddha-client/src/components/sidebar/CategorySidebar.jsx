export default function CategorySidebar({
    selectedCategory,
    setSelectedCategory
}) {

    const categories = [
        "All", "AI", "WebDev", "Coding", "Robotics"
    ]

    return (
        <div className="relative">
            <div className="lg:hidden">
                <label name="select-category">Filter category:</label>
                <select
                    title="select-category"
                    onChange={() => setSelectedCategory(selectedCategory)}
                    className="ml-4 border border-gray-900 rounded-md"
                >
                    {
                        categories.map((category) => (
                            <option>{category}</option>
                        ))
                    }
                </select>

            </div>
            <div className="hidden lg:flex w-60 sticky top-0 h-screen bg-gray-900 flex flex-col text-white">
                {
                    categories.map((category, index) => {
                        return (
                            <button 
                                key={index}
                                className="border-b border-white hover:bg-gray-800 p-4"
                                onClick={() => setSelectedCategory(category)} 
                            >
                                {category}
                            </button>
                        )
                    })
                }
            </div>
        </div>
    )
}