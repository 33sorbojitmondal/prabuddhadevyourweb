export default function Footer() {
    return (
        <footer className="bg-gray-900 p-4 text-white px-4 sm:px-6 md:px-12 lg:px-20">
            Footer
        </footer>
    )
}