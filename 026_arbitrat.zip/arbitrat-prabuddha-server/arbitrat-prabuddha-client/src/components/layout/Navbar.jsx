import { paths } from "../../routes/paths"

import logo from '../../assets/LOGO.png'

export default function Navbar() {

    const navLinks = [
        {
            name: "Events",
            path: paths.EVENTS_PATH
        },
        {
            name: "About",
            path: paths.ABOUT_PATH
        },
        {
            name: "Contact Us",
            path: paths.CONTACT_PATH
        }
    ]

    return (
        <nav className="bg-gray-900 h-20 text-white flex justify-between items-center px-4 sm:px-6 md:px-12 lg:px-20">

            <a href={paths.HOME_PATH}> 
                <img
                    src={logo}
                    className="h-16"
                />
            </a>
            
            {/*  Banner */}
            

            {/* desktop menu */}
            <ul className="hidden lg:flex items-center">
                {
                    navLinks.map((link, index) => {
                        return (
                            <li key={index} className="flex items-center">
                                <a href={link.path} className="p-4 hover:underline underline-offset-2 transition duration-300">
                                    {link.name}
                                </a>
                                {index !== navLinks.length - 1 && (
                                    <div className="w-px h-6 bg-white" />
                                )}
                            </li>
                        )
                    })
                }
            </ul>
        </nav>
    )
}