export default function PageContainer({children}) {
    return (
        <main className="min-h-[calc(100vh-5rem)] px-4 sm:px-6 md:px-12 lg:px-20 space-y-4 py-8">
            {children}
        </main>
    )
}