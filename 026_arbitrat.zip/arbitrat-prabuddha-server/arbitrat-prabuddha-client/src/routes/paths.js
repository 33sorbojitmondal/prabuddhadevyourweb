export const paths = {
    HOME_PATH: "/",
    ABOUT_PATH: "/about",
    EVENTS_PATH: "/events",
    REGISTRATION_PAGE_PATH : "/registration",
    LOGIN_PATH: "/auth",
    CONTACT_PATH: "/contact"
}