// page imports
import About from "../pages/About"
import Contact from "../pages/Contact"
import Events from "../pages/Events"
import Home from "../pages/Home"

// path import
import { paths } from "./paths"

export const routes = [
    {
        path: paths.HOME_PATH,
        element: Home
    },
    {
        path: paths.ABOUT_PATH,
        element: About
    },
    {
        path: paths.CONTACT_PATH,
        element: Contact
    },
    {
        path: paths.EVENTS_PATH,
        element: Events
    },
]