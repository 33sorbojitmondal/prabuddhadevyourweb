import PageContainer from "../components/layout/PageContainer";

export default function About() {
    return (
        <PageContainer>
            <div className="space-y-2">
                <h1 className="text-xl font-semibold text-center lg:text-left">About Prabuddha</h1>
                <p>Techno International New Town, Kolkata is going to organize “Prabuddha”-Tech Fest on February 27th Feb to 1st Mar, 2025, Thursday, Friday and Saturday. We invite your active participation in this Tech Fest by exploring emerging technologies and solving real-world challenges. It aims to foster learning, networking, and collaboration, driving the future of technology forward providing a platform for tech enthusiasts. The primary goal of the Tech Fest is to encourage innovation, creativity and knowledge-sharing to empower future tech leaders and to showcase the advancements in AI, cybersecurity and other emerging technologies.</p>
            </div>

            <div className="space-y-2">
                <h2 className="font-semibold text-center lg:text-left">Guideline for Tech Fest Participants</h2>
                <ul className="">
                <li>- Register within the deadline using the provided link.</li>
                <li>- All undergraduate students are eligible to participate in different competition.</li>
                <li>- No participants are allowed to take part in two parallel competitions.</li>
                <li>- Keep a copy of your registration confirmation and ID card in time of physical verification on the day of events.</li>
                <li>- Carry a laptop, charger, USB drives, and necessary equipment.</li>
                <li>- Arrive at the venue on time and follow the schedule.</li>
                <li>- Follow ethical practices—no plagiarism or rule violations.</li>
                <li>- Cooperate with event coordinators and adhere to instructions.</li>
                <li>- Maintain professional behaviour with judges, organizers, and other participants.</li>
                <li>- Stick to the given time limits for the events.</li>
                <li>- Follow all safety protocols, especially in hardware-related events.</li>
                <li>- espect the venue rules and avoid damaging property.</li>
                <li>- Avoid disruptive behaviour or misconduct during the fest.</li>
                <li>- provide us the mandatory feedback to improve future tech fests.</li>
                <li>- Registration fee for each event is INR 100 (except creative canvas and science day celebration).</li>
                </ul>

            </div>

            <div className="space-y-2">
                <h2 className="text-xl font-semibold text-center lg:text-left">Our History</h2>
            </div>

            <div className="flex flex-col justify-center items-center gap-4">
            <p className="font-semibold text-lg">Take a look at our teaser! </p>
                <iframe src="https://www.youtube.com/embed/vOuu5ZiXTwc?si=esMkUEJT9eBVHiQe" title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen className="w-[560px] h-[450px] max-w-full rounded-md hover:scale-105"></iframe>
            </div>

        </PageContainer>
    )
}