import PageContainer from "../components/layout/PageContainer";

// card imports
import EventCard from "../components/cards/EventCard";

import Searchbar from "../components/search/Searchbar";
import CategorySidebar from "../components/sidebar/CategorySidebar";

import { useSearchParams } from "react-router-dom";
import { useState, useEffect } from 'react';

export default function Events() {

    const params = useSearchParams()

    const [selectedCategory, setSelectedCategory] = useState('All')
    const [events, setEvents] = useState([])


    useEffect(() => {
        console.log(selectedCategory)
        if (selectedCategory === 'All') {
            setEvents(dummyEvents)
        } else {
            setEvents(dummyEvents.filter((event) => event.category === selectedCategory))
        }
    }, [selectedCategory])

    const handleSearch = (text) => {
        setEvents(dummyEvents.filter(event => event.name.toLowerCase().includes(text)))
    }

    return (
        <PageContainer>
            <section className="flex flex-col lg:flex-row items-start gap-4">
                <CategorySidebar 
                    selectedCategory={selectedCategory}
                    setSelectedCategory={setSelectedCategory}
                />
                <section className="w-full flex flex-col justify-start overflow-y-auto">
                    <Searchbar handleSubmit={handleSearch}/>
                    {
                        events.length === 0 ? <p> No such event found! </p> : 
                    
                        <section className="w-full grid place-content-center place-items-center grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
                            {
                                events.map((event, index) => {
                                    return (
                                        <EventCard key={index} event={event}/>
                                    )
                                })
                            }
                        </section>
                    }   
                </section>
            </section>
        </PageContainer>
    )
}

const dummyEvents = [
    {
        id: 1,
        name: "Event 1",
        category: "AI",
        description: "",
        rules: [],
        banner: "",
        eventDate: new Date().getDate(),
        eventTime: new Date().getTime(),
        prize: "100 INR",
        venue: "Kolkata"
    },
    {
        id: 1,
        name: "Event 1",
        category: "AI",
        description: "",
        rules: [],
        banner: "",
        eventDate: new Date().getDate(),
        eventTime: new Date().getTime(),
        prize: "100 INR",
        venue: "Kolkata"
    },
    {
        id: 1,
        name: "Event 1",
        category: "WebDev",
        description: "",
        rules: [],
        banner: "",
        eventDate: new Date().getDate(),
        eventTime: new Date().getTime(),
        prize: "100 INR",
        venue: "Kolkata"
    },
    {
        id: 1,
        name: "Event 1",
        category: "WebDev",
        description: "",
        rules: [],
        banner: "",
        eventDate: new Date().getDate(),
        eventTime: new Date().getTime(),
        prize: "100 INR",
        venue: "Kolkata"
    },
    {
        id: 1,
        name: "Event 1",
        category: "Coding",
        description: "",
        rules: [],
        banner: "",
        eventDate: new Date().getDate(),
        eventTime: new Date().getTime(),
        prize: "100 INR",
        venue: "Kolkata"
    },
    {
        id: 1,
        name: "Event 1",
        category: "Coding",
        description: "",
        rules: [],
        banner: "",
        eventDate: new Date().getDate(),
        eventTime: new Date().getTime(),
        prize: "100 INR",
        venue: "Kolkata"
    },
    {
        id: 1,
        name: "Event 1",
        category: "Robotics",
        description: "",
        rules: [],
        banner: "",
        eventDate: new Date().getDate(),
        eventTime: new Date().getTime(),
        prize: "100 INR",
        venue: "Kolkata"
    },
    {
        id: 1,
        name: "Event 1",
        category: "Robotics",
        description: "",
        rules: [],
        banner: "",
        eventDate: new Date().getDate(),
        eventTime: new Date().getTime(),
        prize: "100 INR",
        venue: "Kolkata"
    },
]