import PageContainer from "../components/layout/PageContainer";

// card imports
import ContactCard from "../components/cards/ContactCard";
import FaqAccordion from "../components/accordion/FaqAccordion";

import { useState } from 'react'
import axios from "axios";

export default function Contact() {

    const [query, setQuery] = useState('')

    return (
        <PageContainer>
            <div className="space-y-2">
                <h2 className="text-xl font-semibold text-center lg:text-left">Organizers of Prabuddha 2025: </h2>
                <div className="w-full grid place-content-center place-items-center grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4"> 
                    {
                        contacts.map((contact, index) => {
                            return (
                                <ContactCard key={index} contact={contact}/>
                            )
                        })
                    }
                </div>
            </div>

            {/* FAQ Accordion */}
            <div className="flex flex-col">
                <h2 className="text-xl font-semibold text-center lg:text-left">Commonly Asked Questions</h2>
                {
                    faqs.map((faq, index) => {
                        return (
                            <FaqAccordion key={index} faq={faq}/>
                        )
                    })
                }
            </div>
            
             {/* Form */}
             <div className="space-y-2 max-w-2xl">
                <h2 className="text-xl font-semibold text-center lg:text-left">Ask your doubt: </h2>
                <form className="flex flex-col lg:flex-row items-center gap-4">
                    <textarea 
                        title="q"
                        className="border border-gray-900 p-2 rounded-md flex-1 w-full"
                        placeholder="Can I...?"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                    />
                    <button
                        onClick={async (e) => {
                            console.log(query)
                            e.preventDefault()
                            await axios.post(`https://arbitrat-prabuddha-server.onrender.com/api/queries/`, {query: query, userId: "102983471928369"})
                        }}
                        title="ask"
                        className="bg-gray-900 text-white text-center px-4 py-2 rounded-md shadow-sm"
                    >
                        Submit
                    </button>
                </form>           
            </div>    

        </PageContainer>
    )
}

const contacts = [
    {
        name: "Rajarshi Dutta",
        email: "rajarshid.02@gmail.com",
        phone: "+91 1234567890"
    },
    {
        name: "Prabuddha Chowdhury",
        email: "prabuddha.chowdhury@gmail.com",
        phone: "+91 0123456789"
    }
]

const faqs = [
    {
        question: "What is the purpose of Prabuddha 2025?",
        answer: "To encourage students to solve real world problems and grow as budding engineers."
    },
    {
        question: "Are there any prizes?",
        answer: "Yes! There are plenty!"
    }
]