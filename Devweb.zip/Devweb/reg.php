<html>
    <head>
        <title>Registration</title>
        <style>
        .body {
                color:black;
                background:#c1f0fc;
            }
            </style>
</head>
<body class = "body">
</form action = "" method = "post">
<center><h2>Registration<h2><br>
<h3>Enter Your Name</h3>
<input type = "text" name = "name" placeholder = "Name" required></input><br>
<h3>Enter Your Email Id</h3>
<input type = "email" name = "email" placeholder = "Email" required></input><br>
<h3>Enter Password</h3>
<input type = "text" name = "pass" placeholder = "Password" required></input><br>
<h3>Enter Your Phone Number</h3>
<input type = "int" name = "phone" placeholder = "Phone Number" required></input><br>
<h3>Enter Your College Name</h3>
<input type = "text" name = "cllg" placeholder = "College Name" required></input><br>
<h3>Enter Your Year of study</h3>
<input type = "text" name = "yos" placeholder = "Year of Study" required></input><br>
<h3>Enter The Event to participate</h3>
<input type = "text" name = "event" placeholder = "Event Selection" required></input><br>
<h3>File upload for student Id</h3>
<input type="file" name="file"><br><br>
<input type = "submit" name = "submit" placeholder = "Submit" required></input><br><br>

<a href = "login.php">login here</a>

</form>

<?php
if (isset($_POST["submit"])) {
    $name=$_POST["name"];
    $email=$_POST["email"];
    $pass=$_POST["pass"];
    $phone=$_POST["phone"];
    $cname=$_POST["cllg"];
    $yos=$_POST["yos"];
    $event=$_POST["event"];
    $file=$_POST["file"];

$query = "insert into users (name,email,pass,phone,cllg,yos,event) values('$name','$email','$pass','$phone','$cllg','$yos','$event')";
if (mysqli_query($connection, $query)) {
    echo("<script>alert('registration successfuly done')</script>");
    header("location:login.php");
} else {
    echo "error :".mysqli_error($connection);
}
}
?>
</body>
</html>