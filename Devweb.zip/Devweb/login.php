<html>
    <head>
        <title>Registration</title>
        <style>
        .body {
                color:black;
                background:#c1f0fc;
            }
            </style>
</head>
<body class = "body">
</form action = "" method = "post">
<center><h2>Login<h2><br>

<h3>Enter Your Email Id</h3>
<input type = "email" name = "email" placeholder = "Email" required></input><br>
<h3>Enter Password</h3>
<input type = "text" name = "pass" placeholder = "Password" required></input><br><br>

<input type = "submit" name = "submit" placeholder = "Submit" required></input><br><br>

<a href = "reg.php">Register here</a>

</form>

</body>
</html>