<?php
$connection = mysqli_connect("localhost", "root", "", "tech_fest");

if(!$connection){
    die("connection failed:" mysqli_connect_error())
}
?>