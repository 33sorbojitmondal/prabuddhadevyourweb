<html>
    <head>
        <title>Event Details</title>
        <style>
            .img {
                height:800px;
                width:1350px;
            }
            .body{
                color:black;
                background:#c1f0fc;
            }
            </style>
</head>
<body class="body">
<nav class="nav">
        <ul><center>
            <a href="http://localhost/Devweb/index.php">Home</a></li>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            <a href="reg.php">Register</a></li>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            <a href="event.php">View Events</a></li>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            <a href="about.php">About us</a></li>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            <a href="contact.php">Contact us</a></li></center>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
</ul>
        </nav>

        <center><h2> Events at TINT</h2></center>
        <h3>PRABUDDHA 2025</h3>
<p>From Thursday, February 27, 2025 -  10:00am<br>
To Saturday, March 01, 2025 - 05:00pm</p>

<h2>About Techno International New Town</h2>
<p>Techno International New Town (formerly Techno India College of Technology) is one of the youngest colleges of the Techno India Group. It started its journey in the year of 2005.The college is the logical development and the rational conclusion of the mission and the vision of the Techno India Group which is one of the largest knowledge management groups in India.
The academic community finds inspiration from India’s ancient past where education was closely associated with the man-making mission. We believe that education is the manifestation of the perfection already in man. We have tried to build a tuneful balance between India’s golden past and her desired destiny to be a super-power in the post- modern age.</p>
<br>
<p><h2>About Prabuddha</h2>
Techno International New Town, Kolkata is going to organize “Prabuddha”-Tech Fest on February 27th Feb to 1st Mar, 2025, Thursday, Friday and Saturday. We invite your active participation in this Tech Fest by exploring emerging technologies and solving real-world challenges. It aims to foster learning, networking, and collaboration, driving the future of technology forward providing a platform for tech enthusiasts. The primary goal of the Tech Fest is to encourage innovation, creativity and knowledge-sharing to empower future tech leaders and to showcase the advancements in AI, cybersecurity and other emerging technologies.
        </p>
        <img class= img src="image\dev.png">
<h2>Contact Details:</h2>
<p>Ms. Samragni Biswas: 8370813555<br>
Ms. Rakhi Dalapati: 9073722426</p>
    </body>
</html>