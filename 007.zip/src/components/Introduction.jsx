import React from 'react'

function Introduction() {
  return (
    <div className='w-full h-[600px] flex items-center justify-center px-[100px]'>
      <div className='w-1/2 bg-amber-200'>About Us </div>
      <div className='w-1/2 bg-green-500'>Hello dev
      </div>
    </div>
  )
}

export default Introduction
