import React from 'react'

function About() {
  return (
    <div className="bg-background text-foreground p-8 mt-20">
    <h1 className="text-4xl font-bold mb-4">About <span className="text-primary">PRABUDDHA 2025</span></h1>
    <p className="mb-6">
    Techno International New Town, Kolkata is going to organize “Prabuddha”-Tech Fest on February 27th Feb to 1st Mar, 2025, Thursday, Friday and Saturday. We invite your active participation in this Tech Fest by exploring emerging technologies and solving real-world challenges. It aims to foster learning, networking, and collaboration, driving the future of technology forward providing a platform for tech enthusiasts. The primary goal of the Tech Fest is to encourage innovation, creativity and knowledge-sharing to empower future tech leaders and to showcase the advancements in AI, cybersecurity and other emerging technologies.
    </p>
    <p className="mb-6">
    The academic community finds inspiration from India’s ancient past where education was closely associated with the man-making mission. We believe that education is the manifestation of the perfection already in man. We have tried to build a tuneful balance between India’s golden past and her desired destiny to be a super-power in the post- modern age.
    </p>

    <h2 className="text-2xl font-semibold mt-8 mb-4">Our Journey so far</h2>
    <div className="px-8 grid grid-cols-2 gap-4 mb-8">
        <div className="text-center">
            <h3 className="text-3xl font-bold">5000+</h3>
            <p className="text-muted-foreground">Hackers</p>
        </div>
        <div className="text-center">
            <h3 className="text-3xl font-bold">50+</h3>
            <p className="text-muted-foreground">Partners</p>
        </div>
        <div className="text-center">
            <h3 className="text-3xl font-bold">70+</h3>
            <p className="text-muted-foreground">Hack hours</p>
        </div>
        <div className="text-center">
            <h3 className="text-3xl font-bold">50+</h3>
            <p className="text-muted-foreground">Mentors</p>
        </div>
        <div className="text-center">
            <h3 className="text-3xl font-bold">85+</h3>
            <p className="text-muted-foreground">Events</p>
        </div>
        <div className="text-center">
            <h3 className="text-3xl font-bold">220+</h3>
            <p className="text-muted-foreground">Projects</p>
        </div>
    </div>

    <div className="grid grid-cols-3 gap-4">
        <img className="rounded-lg" src="https://www.brightidea.com/wp-content/uploads/Hackathon-Benefits.png" alt="Event image 1" />
        <img className="rounded-lg" src="https://shorturl.at/ugZyl" alt="Event image 2" />
        <img className="rounded-lg bg" src="https://www.ivybusiness.iastate.edu/files/2024/11/Photo-of-2024-Hackathon-2160x807-1.jpg" alt="Event image 3" />
    </div>
    <div className="bg-background p-8">
          <h2 className="text-3xl font-bold text-foreground mb-6"></h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-card p-4 rounded-lg shadow-lg">
              <img className="w-full h-48 object-cover rounded-lg" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1528&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Abhay" />
              <h3 className="text-xl font-semibold mt-2">Abhay</h3>
              <p className="text-muted-foreground">Student & Researcher</p>
              <p className="text-muted-foreground">CHARUSAT</p>
              <div className="flex justify-between mt-4">
                <a href="#" className="text-primary">X</a>
                <a href="#" className="text-primary">in</a>
              </div>
            </div>
            <div className="bg-card p-4 rounded-lg shadow-lg">
              <img className="w-full h-48 object-cover rounded-lg" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1528&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Anubhav" />
              <h3 className="text-xl font-semibold mt-2">Anubhav</h3>
              <p className="text-muted-foreground">Co-Founder</p>
              <p className="text-muted-foreground">Callchimp.ai</p>
              <div className="flex justify-between mt-4">
                <a href="#" className="text-primary">X</a>
                <a href="#" className="text-primary">in</a>
              </div>
            </div>
            <div className="bg-card p-4 rounded-lg shadow-lg">
              <img className="w-full h-48 object-cover rounded-lg" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1528&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Arghya" />
              <h3 className="text-xl font-semibold mt-2">Arghya</h3>
              <p className="text-muted-foreground">Dev Ambassador</p>
              <p className="text-muted-foreground">Router Protocol</p>
              <div className="flex justify-between mt-4">
                <a href="#" className="text-primary">X</a>
                <a href="#" className="text-primary">in</a>
              </div>
            </div>
            <div className="bg-card p-4 rounded-lg shadow-lg">
              <img className="w-full h-48 object-cover rounded-lg" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1528&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Ashutosh" />
              <h3 className="text-xl font-semibold mt-2">Ashutosh</h3>
              <p className="text-muted-foreground">Developer Relations Engineer</p>
              <p className="text-muted-foreground">AvaLabs</p>
              <div className="flex justify-between mt-4">
                <a href="#" className="text-primary">X</a>
                <a href="#" className="text-primary">in</a>
              </div>
            </div>
          </div>
        </div>
</div>
  )
}

export default About
