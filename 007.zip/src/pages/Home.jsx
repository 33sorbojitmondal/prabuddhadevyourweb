import React from 'react'
import Hero from '../components/Hero'
// import Intro from '../components/Introduction'
import Timer from '../components/counDown'
import Footer from '../components/footer'

function Home() {
  return (
    <>
   <Hero/>
   {/* <Intro/> */}
   <Timer/>

    </>
  )
}

export default Home
