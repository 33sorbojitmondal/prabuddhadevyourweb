import React from 'react'

function Event() {
  return (
    <div>
      <section className="bg-background p-8 mt-20"> 
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-card rounded-lg shadow-lg overflow-hidden">
            <img undefinedhidden="true" alt="Artificial Intelligence" src="https://openui.fly.dev/openui/300x200.svg?text=🧠" className="w-full h-40 object-cover" />
            <div className="p-4">
              <h3 className="text-primary font-bold text-lg text-center">Artificial Intelligence</h3>
            </div>
          </div>
          <div className="bg-card rounded-lg shadow-lg overflow-hidden">
            <img undefinedhidden="true" alt="Machine Learning" src="https://openui.fly.dev/openui/300x200.svg?text=📈" className="w-full h-40 object-cover" />
            <div className="p-4">
              <h3 className="text-primary font-bold text-lg text-center">Machine Learning</h3>
            </div>
          </div>
          <div className="bg-card rounded-lg shadow-lg overflow-hidden">
            <img undefinedhidden="true" alt="Web Development" src="https://openui.fly.dev/openui/300x200.svg?text=💻" className="w-full h-40 object-cover" />
            <div className="p-4">
              <h3 className="text-primary font-bold text-lg text-center">Web Development</h3>
            </div>
          </div>
          <div className="bg-card rounded-lg shadow-lg overflow-hidden">
            <img undefinedhidden="true" alt="Python" src="https://openui.fly.dev/openui/300x200.svg?text=🐍" className="w-full h-40 object-cover" />
            <div className="p-4">
              <h3 className="text-primary font-bold text-lg text-center">Python</h3>
            </div>
          </div>
        </div>
      </section>

    </div>
  )
}

export default Event
