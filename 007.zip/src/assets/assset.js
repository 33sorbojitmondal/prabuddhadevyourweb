import About_Home from './about_Home.jpg'
import Banner from './herobanner.png'
import Logo from './favicon.png'
import Website from './website.svg'
import Facebook from './facebook.svg'
import Instagram from './instagram.svg'

export const assets= {
    About_Home,
    Banner,
    Logo,
    Website,
    Facebook,
    Instagram
}