import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
// import Header from './components/Header'
import About from './pages/About.jsx'
import Header from './components/Header.jsx'
import Footer from './components/footer.jsx'
import Event from './pages/Event.jsx'

function App() {
  return (
    <>
    <Header/>
    <Routes>
     <Route path='/' element={<Home/>}/>
     <Route path='/about' element={<About/>}/>
     <Route path='/event' element={<Event/>}/>
    </Routes>
    <Footer/>
    </>
  )
}

export default App
