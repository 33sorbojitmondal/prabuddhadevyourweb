import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './App.css'
import Home from './components/Home'
import About from './components/about'
import Contact from './components/contact'
import Register from './components/register'
import Events from './components/events'
// import About from './components/About'
// import Contact from './components/Contact'
// import Events from './components/Events'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
         <Route path="/about" element={<About />} />
         <Route path="/register" element={<Register />} />
         <Route path="/contact" element={<Contact />} />
         <Route path="/events" element={<Events />} />
        </Routes>    
        </BrowserRouter>
  )
}

export default App