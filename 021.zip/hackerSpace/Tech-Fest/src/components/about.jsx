import React from 'react'
import Footer from './footer.jsx'
const about = () => {
  return (
    <>
    <section className='bg-gray-900 h-screen'>
    <div className="mx-auto max-w-screen-xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 md:items-center md:gap-8">
        <div>
          <div className="max-w-lg md:max-w-none">
            <h2 className="text-2xl font-semibold text-gray-900 sm:text-3xl">
              Lorem ipsum dolor sit amet consectetur adipisicing elit.
            </h2>
  
            <p className="mt-4  text-white text-lg">
            <p className='text-3xl font-bold text-cyan-400'> TECHNO INTERNATION NEWTOWN, KOLKATA </p> is going to organize “Prabuddha”-Tech Fest on February 27th Feb to 1st Mar, 2025, Thursday, Friday and Saturday. We invite your active participation in this Tech Fest by exploring emerging technologies and solving real-world challenges. The primary goal of the Tech Fest is to encourage innovation, creativity and knowledge-sharing to empower future tech leaders and to showcase the advancements in AI, cybersecurity and other emerging technologies.
            </p>
          </div>
        </div>
  
        <div className='mt-8'>
        <iframe  width="560" height="350" src="https://www.youtube.com/embed/vOuu5ZiXTwc?si=vmPl_UCBZqMnT-7F" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen/>
        </div>
      </div>
    </div>
  </section>
  <Footer />
    </>
  )
}

export default about