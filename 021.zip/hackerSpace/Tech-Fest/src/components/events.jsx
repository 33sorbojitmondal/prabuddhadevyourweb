import React from 'react';
import Footer from './footer.jsx';

const Events = () => {
  return (
    <>
      <div className="bg-gray-900 p-8 h-screen">
        <h1 className="text-3xl font-bold mb-4 text-cyan-400 text-center">Join our events</h1>
        <p className="text-lg text-gray-100 text-center mb-8">
          Engage in our events to chat about learning trends and experience our collaborative online learning platform first-hand.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white shadow-lg rounded-lg overflow-hidden">
            <div className="p-4">
              <h3 className="text-lg font-medium">Debate with AI</h3>
              <p className="text-gray-500">March 1, 2025 · 9:00 AM - 10:00 AM</p>
              <p className="text-yellow-600 font-bold">Coding</p>
            </div>
          </div>

          <div className="bg-white shadow-lg rounded-lg overflow-hidden">
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-2">Robotics</h2>
              <p className="text-gray-500">March 1, 2025 · 9:00 AM - 10:00 AM</p>
              <p className="text-yellow-600 font-bold">Robotics</p>
            </div>
          </div>

          <div className="bg-white shadow-lg rounded-lg overflow-hidden">
            <div className="p-4">
              <h3 className="text-lg font-medium">Online Learning Engagement</h3>
              <p className="text-gray-500">March 1, 2025 · 9:00 AM - 10:00 AM (GMT)</p>
              <p className="text-yellow-600 font-bold">Web Development</p>
            </div>
          </div>

          <div className="bg-white shadow-lg rounded-lg overflow-hidden">
            <div className="p-4">
              <h3 className="text-lg font-medium">Journaling</h3>
              <p className="text-gray-500">March 1, 2025 · 9:00 AM - 10:00 AM (GMT)</p>
              <p className="text-yellow-600 font-bold">Technology</p>
            </div>
          </div>

          <div className="bg-white shadow-lg rounded-lg overflow-hidden">
            <div className="p-4">
              <h3 className="text-lg font-medium">Learners Method</h3>
              <p className="text-gray-500">March 1, 2025 · 9:00 AM - 10:00 AM (GMT)</p>
              <p className="text-yellow-600 font-bold">Technology</p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Events;