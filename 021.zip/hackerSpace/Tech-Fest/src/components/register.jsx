import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import axios from 'axios';
import 'react-toastify/dist/ReactToastify.css';  // Import this in your component or main file

const Signup = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    college: '',
    year: '',
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { name, email, password,phone, college, year } = formData;
    
    // Check for empty fields
    if (!name || !email || !password || !phone || !college) {
      toast.error('Please fill in all fields');
    }

    try {
      const response = await axios.post('http://localhost:8000/auth/signup', formData);
      console.log(response);
      
      if (response.data.success) {
        toast.success('Signup successful! Redirecting to login...');
        setTimeout(() => {
          navigate('/');
        }, 2000);  // Delay the navigation to allow user to see the toast
      }
      else {
        toast.error('Signup failed, please try again.');
      }
    } catch (error) {
      console.error(error);
      if(error.response.data.message === 'User already exists')
        toast.error(error.response.data.message);
    else if(error.response.data.error.details[0].message)
      toast.error(error.response.data.error.details[0].message);
      else
      toast.error('An error occurred, please try again later.');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md">
        <h2 className="text-2xl font-bold text-center text-gray-900">Sign Up</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name Input */}
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700">
              Name
            </label>
            <input
              type="text"
              name="name"
              id="name"
              value={formData.name}
              onChange={handleChange}
              className="w-full px-3 py-2 mt-1 text-gray-900 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              required
              autoFocus
            />
          </div>
          
          {/* Email Input */}
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
              Email
            </label>
            <input
              type="email"
              name="email"
              id="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full px-3 py-2 mt-1 text-gray-900 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              required
              placeholder='Enter your email address'
            />
          </div>
          
          {/* Password Input */}
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">
              Password
            </label>
            <input
              type="password"
              name="password"
              id="password"
              value={formData.password}
              onChange={handleChange}
              className="w-full px-3 py-2 mt-1 text-gray-900 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              required
              placeholder='Enter your password'
            />
          </div>


          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
              Contact Number
            </label>
            <input
              type="text"
              name="phone"
              id="phone"
              value={formData.phone}
              onChange={handleChange}
              className="w-full px-3 py-2 mt-1 text-gray-900 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              required
              placeholder='Enter your phonenumber'
            />
          </div>



          <div>
            <label htmlFor="college" className="block text-sm font-medium text-gray-700">
              College Name
            </label>
            <input
              type="text"
              name="college"
              id="college"
              value={formData.college}
              onChange={handleChange}
              className="w-full px-3 py-2 mt-1 text-gray-900 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              required
              placeholder='Enter your college name'
            />
          </div>
          

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Year of Study
            </label>
            <div className="flex space-x-4 mt-1">
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="year"
                  value="1"
                  checked={formData.year === '1'}
                  onChange={handleChange}
                  className="form-radio text-indigo-600"
                />
                <span className="ml-2">1</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="year"
                  value="2"
                  checked={formData.year === '2'}
                  onChange={handleChange}
                  className="form-radio text-indigo-600"
                />
                <span className="ml-2">2</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="year"
                  value="3"
                  checked={formData.year === '3'}
                  onChange={handleChange}
                  className="form-radio text-indigo-600"
                />
                <span className="ml-2">3</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="year"
                  value="4"
                  checked={formData.year === '4'}
                  onChange={handleChange}
                  className="form-radio text-indigo-600"
                />
                <span className="ml-2">4</span>
              </label>
            </div>
          </div>


          {/* <div>
            <label className="block text-sm font-medium text-gray-700">
              Events
            </label>
            <div className="flex space-x-4 mt-1">
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="events"
                  value="Solution Challenge"
                  checked={formData.event === 'Solution Challenge'}
                  onChange={handleChange}
                  className="form-radio text-indigo-600"
                />
                <span className="ml-2">Solution Challenge</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="year"
                  value="Dev Your Web"
                  checked={formData.event === 'Dev Your Web'}
                  onChange={handleChange}
                  className="form-radio text-indigo-600"
                />
                <span className="ml-2">Dev Your Web</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="yearOfStudy"
                  value="Design Spark"
                  checked={formData.event === 'Design Spark'}
                  onChange={handleChange}
                  className="form-radio text-indigo-600"
                />
                <span className="ml-2">Design Spark</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="yearOfStudy"
                  value="Robo Challenge"
                  checked={formData.event === 'Robo Challenge'}
                  onChange={handleChange}
                  className="form-radio text-indigo-600"
                />
                <span className="ml-2">Robo Challenge</span>
              </label>
            </div>
          </div> */}

          {/* Submit Button */}
          <div>
            <button
              type="submit"
              className="w-full px-4 py-2 text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
            >
              Register
            </button>

          </div>
        </form>
        
      </div>
      <ToastContainer />
    </div>
  );
};

export default Signup;
