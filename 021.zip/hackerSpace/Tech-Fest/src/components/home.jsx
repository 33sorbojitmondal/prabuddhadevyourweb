import React from 'react'
import Footer from './footer.jsx'
import { IoIosInformationCircleOutline } from "react-icons/io";


const Home = () => {
return (
    <>
  <section className="bg-gray-900">
    <div className="flex justify-between">
      <div>
        <img className="w-17 h-15 rounded-full ml-2 mt-2" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThvoShoXh_VdXW6COfIhfuW_NAWnQOrJk4RQ&s"  />
      </div>
    <div className='w-full justify-end flex items-center'> 
  <a className="w-auto rounded-sm bg-cyan-400 px-10 py-3 mt-3 mr-3  text-sm font-medium text-white shadow-sm hover:bg-cyan-700 focus:ring-3 focus:outline-hidden cursor-pointer  " href='/contact'>
          
        
          Contact Us
        </a>
        <div className="w-auto rounded-full bg-cyan-400 mx-7  mt-3 text-sm font-medium text-white shadow-sm hover:bg-cyan-700 focus:ring-3 focus:outline-hidden cursor-pointer scale-[3] ">
        <a href="/about"><IoIosInformationCircleOutline className='scale-[0.9] ' /></a>
        </div>
    </div>
    </div>

    <div className=" mt-2 carousel w-full">
  <div id="slide1" className="carousel-item relative w-full">
    <img
      src="https://img.daisyui.com/images/stock/photo-1625726411847-8cbb60cc71e6.webp"
      className="w-full" />
    <div className="absolute left-5 right-5 top-1/2 flex -translate-y-1/2 transform justify-between">
      <a href="#slide4" className="btn btn-circle">❮</a>
      <a href="#slide2" className="btn btn-circle">❯</a>
    </div>
  </div>
  <div id="slide2" className="carousel-item relative w-full">
    <img
      src="https://img.daisyui.com/images/stock/photo-1609621838510-5ad474b7d25d.webp"
      className="w-full" />
    <div className="absolute left-5 right-5 top-1/2 flex -translate-y-1/2 transform justify-between">
      <a href="#slide1" className="btn btn-circle">❮</a>
      <a href="#slide3" className="btn btn-circle">❯</a>
    </div>
  </div>
  <div id="slide3" className="carousel-item relative w-full">
    <img
      src="https://img.daisyui.com/images/stock/photo-1414694762283-acccc27bca85.webp"
      className="w-full" />
    <div className="absolute left-5 right-5 top-1/2 flex -translate-y-1/2 transform justify-between">
      <a href="#slide2" className="btn btn-circle">❮</a>
      <a href="#slide4" className="btn btn-circle">❯</a>
    </div>
  </div>
  <div id="slide4" className="carousel-item relative w-full">
    <img
      src="https://img.daisyui.com/images/stock/photo-1665553365602-b2fb8e5d1707.webp"
      className="w-full" />
    <div className="absolute left-5 right-5 top-1/2 flex -translate-y-1/2 transform justify-between">
      <a href="#slide3" className="btn btn-circle">❮</a>
      <a href="#slide1" className="btn btn-circle">❯</a>
    </div>
  </div>
</div>

  <div className="mx-auto max-w-screen-xl px-4 py-10 lg:flex lg:h-screen ">
    <div className="mx-auto max-w-xl text-center">
      <h1 className="text-3xl font-extrabold sm:text-5xl text-white">
      PRABUDDHA 2025
        <strong className="font-extrabold text-cyan-400 sm:block"> TECH FEST </strong>
      </h1>

      <p className="mt-4 sm:text-xl/relaxed text-white">
      From Thursday, February 27, 2025 -  10:00am
To Saturday, March 01, 2025 - 05:00pm
      </p>
      


      <div className="mt-8 flex flex-wrap justify-center gap-4">
        <a
          className="block w-full rounded-sm bg-cyan-400 px-12 py-3 text-sm font-medium text-white shadow-sm hover:bg-cyan-700 focus:ring-3 focus:outline-hidden sm:w-auto"
          href="/register"
        >
          Register Now 
        </a>

        <a
          className="block w-full rounded-sm px-12 py-3 text-sm font-medium text-cyan-400 shadow-sm hover:text-cyan-700 focus:ring-3 focus:outline-hidden sm:w-auto"
          href="/events"
        >
          View Events
        </a>
      </div>
  <div className="grid mt-4 justify-center bg-gray-900 text-white text-bold grid-flow-col gap-5 text-center auto-cols-max">
  <div className="flex flex-col">
    <span className="countdown font-mono text-5xl">
      <span style={{"--value":15}}></span>
    </span>
    days
  </div>
  <div className="flex flex-col">
    <span className="countdown font-mono text-5xl">
      <span style={{"--value":10}}></span>
    </span>
    hours
  </div>
  <div className="flex flex-col">
    <span className="countdown font-mono text-5xl">
      <span style={{"--value":24}}></span>
    </span>
    min
  </div>
  <div className="flex flex-col">
    <span className="countdown font-mono text-5xl">
      <span style={{"--value":59}}></span>
    </span>
    sec
  </div>
</div>
  <p className='my-10 text-cyan-400'>Techfest is the annual science and technology festival of the Indian Institute of Technology Bombay, consisting of social initiatives and outreach programs throughout the year.</p>
    </div>
  </div>



</section>
<Footer/>
    </>
)
}

export default Home