// import './App.css';
// var countdown= new Date("Feb 29, 2025 00:00:00").getTime();

// var x= setInterval(function() {
//   var now = new Date().getTime();

//   var distance = countdown-now;

//   var days = Math.floor(distance/(1000*60*60*24));
//   var hours = Math.floor((distance%(1000*60*60*24))/(1000*60*60));
//   var minutes = Math.floor((distance%(1000*60*60))/(1000*60));
//   var seconds =Math.floor((distance%(1000*60))/1000);

// document.getElementById("CountDown").innerHTML = days + "d" +hours+"h"+minutes+"m"+seconds+"s";
//   if(distance <= 0){
//     clearInterval(x);
//     document.getElementById("CountDown").innerHTML="Time to Go For Tech Fest";

//   }
// },1000);
function App() {
  return (
  <>

    <nav id="nav-top">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuoDceuSU8EgZpudQEmaM62Gbb8AhK86WgOg&s" id="logo">
            <div class="navStyle"><a id="Home-Page" title="Home-Page" href="./index.html">Home-Page</a></div>
            <div class="navStyle"><a id="About-Us-Page" title="About-Us-Page" href="./About.html">About-Us-Page</a></div>
            <div class="navStyle"><a id="Event-Details" title="Event-Details" href="./Event-Details.html">Event-Details</a></div>
            <div class="navStyle"><a id="Reg-Page" title="Reg-Page" href="./reg.html">Reg-Page</a></div>
            <div class="navStyle"><a id="Contact-Us" title="Contact-Us" href="#ContuctUs">Contact-Us</a></div>
            <div class="navStyle"><a id="Query" title="Query" href="#Query">Query</a></div>

    </nav>
    <br><br><br><br><br><br>

    <li class="liStyle"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuoDceuSU8EgZpudQEmaM62Gbb8AhK86WgOg&s" style="height: fit-content; float: left;"></li>
            <li class="liStyle">Techno International New Town, Kolkata is going to organize “Prabuddha”-Tech Fest on February 27th Feb to 1st Mar, 2025, Thursday, Friday and Saturday. We invite your active participation in this Tech Fest by exploring emerging technologies and solving real-world challenges. It aims to foster learning, networking, and collaboration, driving the future of technology forward providing a platform for tech enthusiasts. The primary goal of the Tech Fest is to encourage innovation, creativity and knowledge-sharing to empower future tech leaders and to showcase the advancements in AI, cybersecurity and other emerging technologies.</li>
            <br><br><br><br><br><br>
            <div id="show-mid">
            <li class="liStyle"><a id="Home-Page" title="Home-Page" href="./index.html">Home-Page</a></li>
            <li class="liStyle"><a id="About-Us-Page" title="About-Us-Page" href="./About.html">About-Us-Page</a></li>
            <li class="liStyle"><a id="Event-Details" title="Event-Details" href="./Event-Details.html">Event-Details</a></li>
            <li class="liStyle"><a id="Reg-Page" title="Reg-Page" href="./reg.html">Reg-Page</a></li>
            <li class="liStyle"><a id="Contact-Us" title="Contact-Us" href="#ContuctUs">Contact-Us</a></li>
            <li class="liStyle"><a id="Query" title="Query" href="#Query">Contact-Us</a></li>
            </div>
            <br>
            <div id="CountDown"></div>

          <br><br><br><br><br><br><br><br>
          <hr>
            <footer><br><br>
              <div id="Query">
                <span></span>
              </div>
              <div id="ContuctUs">
                <address>
                  <span>Techno International New Town</span><br>
                  <span>Block - DG 1/1, Action Area 1
                  New Town, Kolkata - 700156</span><br>
                 <a href="tal:18002588154"  style="color:black">Toll Free No :18002588154</a><br>
                  <a href="tal:+91-33-23242050/2091" style="color:black">Phone :+91-33-23242050/2091</a>
                </address>
              </div><br><br>
            </footer>
            </>
  );
}

export default App;
